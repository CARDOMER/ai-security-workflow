import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.HostnameVerifier

fun HttpsURLConnection.trainingPolicy() {
    hostnameVerifier = HostnameVerifier { _, _ -> true }
}
