
dependencies {
    implementation ( libs.text.tools )
}
